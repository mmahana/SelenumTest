package SeleniumTest.SeleniumTest;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

public class SeleniumTest {
	WebDriver driver;
	String randomNum;

	@BeforeClass
	public void beforeClass() throws InterruptedException {

		File file = new File(
				"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		System.setProperty("webdriver.firefox.bin", file.getAbsolutePath());
		driver = new FirefoxDriver();
		driver.get("https://pi.pardot.com/");
		Thread.sleep(10000);
		WebElement id = driver.findElement(By.id("email_address"));
		WebElement pass = driver.findElement(By.name("password"));
		WebElement button = driver.findElement(By.name("commit"));
		id.sendKeys("pardot.applicant@pardot.com");
		pass.sendKeys("Applicant2012");
		button.submit();
		Thread.sleep(5000);
		WebElement marketingMenu = driver.findElement(By.linkText("Marketing"));
		Actions action = new Actions(driver);
		action.moveToElement(marketingMenu).perform();
		WebElement Segmentation = driver.findElement(By
				.linkText("Segmentation"));
		action.moveToElement(Segmentation).perform();
		Thread.sleep(5000);
		WebElement Lists = driver.findElement(By
				.xpath(".//*[@id='dropmenu-marketing']/li[11]/ul/li[1]/a"));
		action.moveToElement(Lists).click().perform();
		Thread.sleep(5000);
		driver.findElement(By.id("listxistx_link_create")).click();
		Thread.sleep(5000);
		randomNum = "Random_" + (int) (Math.random() * 50 + 1);
		driver.findElement(By.xpath(".//*[@id='name']")).sendKeys(
				"" + randomNum);
		driver.findElement(By.id("save_information")).submit();

	}

	@Test
	public void testDuplicateList() throws InterruptedException {
		Thread.sleep(10000);
		WebElement marketing_Menu = driver
				.findElement(By.linkText("Marketing"));
		Actions action = new Actions(driver);
		action.moveToElement(marketing_Menu).perform();
		WebElement Segmentation = driver.findElement(By
				.linkText("Segmentation"));
		action.moveToElement(Segmentation).perform();
		Thread.sleep(5000);
		WebElement Lists = driver.findElement(By
				.xpath(".//*[@id='dropmenu-marketing']/li[11]/ul/li[1]/a"));
		action.moveToElement(Lists).click().perform();
		Thread.sleep(5000);
		driver.findElement(By.id("listxistx_link_create")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='name']")).sendKeys(randomNum);
		driver.findElement(By.id("save_information")).submit();
		Assert.assertEquals(
				driver.findElement(
						By.xpath(".//*[@id='li_form_update']/div[1]"))
						.getText(),
				"Please correct the errors below and re-submit",
				"Both string are same and validation error encoutered");

		driver.close();
	}
}
